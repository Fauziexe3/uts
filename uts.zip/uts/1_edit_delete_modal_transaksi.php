<!-- MODAL EDITT DATAA -->

<div class="modal fade" id="edit_<?php echo $data['no_nota']; ?>" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel"><b>Ubah data transaksi</b></h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">x</button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <form method="POST" action="php/edit_transaksi.php" enctype="multipart/form-data">
                        <input type="hidden" class="form-control" name="no_nota"
                            value="<?php echo $data['no_nota']; ?>">
                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Nama</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="nama_pelanggan"
                                    value="<?php echo $data['nama_pelanggan']; ?>" placeholder="Masukkan nama">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Jenis</label>
                            </div>
                            <div class="col-sm-10">
                                <select name="jenis" id="" class="form-control" required>

                                    <option value="<?= $data['jenis']; ?>" hidden><?= $data['jenis']; ?></option>
                                    <option value="mobil">mobil</option>
                                    <option value="motor">motor</option>

                                </select>
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Total bayar</label>
                            </div>
                            <div class="col-sm-10">
                                <select name="total_bayar" id="" class="form-control" required>

                                    <option value="<?= $data['total_bayar']; ?>" hidden><?= $data['total_bayar']; ?>
                                    </option>
                                    <option value="10000">10000
                                    </option>
                                    <option value="5000">5000
                                    </option>

                                </select>
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Tanggal</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" name="tanggal"
                                    value="<?php echo $data['tanggal']; ?>">
                            </div>
                        </div>

                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span
                        class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="edit" class="btn btn-primary"><span
                        class="glyphicon glyphicon-check"></span>
                    Update</a>
                    </form>
            </div>
        </div>
    </div>
</div>


<!-- MODAL DELETEE!! -->
<div class="modal fade" id="delete_<?php echo $data['no_nota']; ?>" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <h2 class="text-center"><b>Apa kamu yakin ingin menghapus data ini!</b></h2>
                <p class="text-center">Dengan nama
                <h2 class="text-center"><?php echo $data['nama_pelanggan']; ?></h2>
                </p>
                <p class="text-center">Bernota
                <h2 class="text-center"><?php echo $data['no_nota']; ?></h2>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span
                        class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="php/delete_transaksi.php?no_nota=<?php echo $data['no_nota']; ?>" class="btn btn-danger"><span
                        class="glyphicon glyphicon-trash"></span> Yes</a>
            </div>

        </div>
    </div>
</div>