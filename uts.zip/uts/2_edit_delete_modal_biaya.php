<!-- MODAL EDITT DATAA -->

<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel"><b>Ubah data biaya</b></h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">x</button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <form method="POST" action="php/edit_biaya.php" enctype="multipart/form-data">
                        <input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Kendaraan:</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="kendaraan"
                                    value="<?php echo $row['kendaraan']; ?>" placeholder="Masukkan kendaraan">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Bayar:</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="bayar"
                                    value="<?php echo $row['bayar']; ?>" placeholder="Masukkan bayar">
                            </div>
                        </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span
                        class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="edit" class="btn btn-primary"><span
                        class="glyphicon glyphicon-check"></span>
                    Update</a>
                    </form>
            </div>
        </div>
    </div>
</div>


<!-- MODAL DELETEE!! -->
<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <h2 class="text-center"><b>Apa kamu yakin ingin menghapus data ini!</b></h2>
                <p class="text-center">Dengan jenis kendaraan
                <h2 class="text-center"><?php echo $row['kendaraan']; ?></h2>
                </p>
                <p class="text-center">Ber id
                <h2 class="text-center"><?php echo $row['id']; ?></h2>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span
                        class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="php/delete_biaya.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"><span
                        class="glyphicon glyphicon-trash"></span> Yes</a>
            </div>

        </div>
    </div>
</div>