<!-- MODAL EDITT DATAA -->

<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel"><b>Ubah data user</b></h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">x</button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <form method="POST" action="php/edit_user.php" enctype="multipart/form-data">
                        <input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Username:</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="username"
                                    value="<?php echo $row['username']; ?>" placeholder="Masukkan username">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Nama:</label>
                                r
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="nama" value="<?php echo $row['nama']; ?>"
                                    placeholder="Masukkan nama">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2 mt-2">
                                <label class="control-label modal-label">Level:</label>
                            </div>
                            <div class="col-sm-10">
                                <select name="role_id" id="role_id" class="form-control">
                                    <option value="<?= $row['role_id'] ?>" hidden><?= $row['role_id']; ?></option>
                                    <option value="admin">admin</option>
                                    <option value="karyawan">karyawan</option>
                                </select>
                            </div>
                        </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span
                        class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="edit" class="btn btn-primary"><span
                        class="glyphicon glyphicon-check"></span>
                    Update</a>
                    </form>
            </div>
        </div>
    </div>
</div>


<!-- MODAL DELETEE!! -->
<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <h2 class="text-center"><b>Apa kamu yakin ingin menghapus data ini!</b></h2>
                <p class="text-center">Dengan nama
                <h2 class="text-center"><?php echo $row['nama']; ?></h2>
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span
                        class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="php/delete_user.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"><span
                        class="glyphicon glyphicon-trash"></span> Yes</a>
            </div>

        </div>
    </div>
</div>