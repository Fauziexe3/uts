<!DOCTYPE html>
<?php
session_start();
if (!isset($_SESSION['id'])) {
    die("<b>Oops!</b> Access Failed.
<p>Sistem Logout. Anda harus melakukan Login kembali.</p>
<button type='button' onclick=location.href='./'>Back</button>");
}
include "php/koneksi.php";

$tampilPeg = mysqli_query($db, "SELECT * FROM user WHERE id='$_SESSION[id]'");
$peg = mysqli_fetch_array($tampilPeg);

$jumlah_transaksi = mysqli_query($db, "SELECT * FROM tb_transaksi");
$transaksi = mysqli_num_rows($jumlah_transaksi);
?>

<html lang="en">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Atlantis Lite - Bootstrap 4 Admin Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="shortcut icon" href="assets/img/6.jpg" type="image/x-icon">
    <!-- <link rel="stylesheet" type="text/css" href="assets/js/dataTable.bootstrap.min.css"> -->


    <!-- Fonts and icons -->
    <script src="assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
    WebFont.load({
        google: {
            "families": ["Lato:300,400,700,900"]
        },
        custom: {
            "families": ["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands",
                "simple-line-icons"
            ],
            urls: ['assets/css/fonts.min.css']
        },
        active: function() {
            sessionStorage.fonts = true;
        }
    });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/atlantis.min.css">

</head>

<body>
    <div class="wrapper">
        <div class="main-header">
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="red">

                <a href="index.html" class="logo">
                    <h2 style="margin-top: 13px;margin-left: 50px;color: white;justify-content:flex-start;">Karyawan
                        Page
                    </h2>
                </a>
                <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse"
                    data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <i class="icon-menu"></i>
                    </span>
                </button>
                <button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
                <div class="nav-toggle">
                    <button class="btn btn-toggle toggle-sidebar">
                        <i class="icon-menu"></i>
                    </button>
                </div>
            </div>
            <!-- End Logo Header -->

            <!-- Navbar Header -->
            <nav class="navbar navbar-header navbar-expand-lg" data-background-color="red">

                <div class="container-fluid">

                    <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">

                        <li class="nav-item dropdown hidden-caret">
                            <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#"
                                aria-expanded="false">
                                <div class="avatar-sm">
                                    <img src="assets/img/6.jpg" alt="..." class="avatar-img rounded-circle">
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-user animated fadeIn">
                                <div class="dropdown-user-scroll scrollbar-outer">
                                    <li>
                                        <div class="user-box">
                                            <div class="avatar-lg"><img src="assets/img/6.jpg" alt="image profile"
                                                    class="avatar-img rounded"></div>
                                            <div class="u-text">
                                                <h4><?= $peg['nama'] ?></h4>
                                                <p class="text-muted"><?= $peg['role_id'] ?></p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="dashboard_kary.php">Beranda</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="php/logout.php">Logout</a>
                                    </li>
                                </div>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
            <!-- End Navbar -->
        </div>

        <!-- Sidebar -->
        <div class="sidebar sidebar-style-2">
            <div class="sidebar-wrapper scrollbar scrollbar-inner">
                <div class="sidebar-content">
                    <div class="user">
                        <div class="avatar-sm float-left mr-2">
                            <img src="assets/img/6.jpg" alt="..." class="avatar-img rounded-circle">
                        </div>
                        <div class="info">
                            <a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                                <span>
                                    <?= $peg['nama'] ?>
                                    <span class="user-level"><?= $peg['role_id'] ?></span>
                                    <span class="caret"></span>
                                </span>
                            </a>
                            <div class="clearfix"></div>

                            <div class="collapse in" id="collapseExample">
                                <ul class="nav">
                                    <li>
                                        <a href="#profile">
                                            <span class="link-collapse">My Profile</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#edit">
                                            <span class="link-collapse">Edit Profile</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <ul class="nav nav-danger">
                        <li class="nav-item active">
                            <a href="dashboard_kary.php" class="collapsed" aria-expanded="false">
                                <i class="fas fa-home"></i>
                                <p>Beranda</p>
                            </a>
                        </li>
                        <li class="nav-section">
                            <span class="sidebar-mini-icon">
                                <i class="fa fa-ellipsis-h"></i>
                            </span>
                            <h4 class="text-section">Components</h4>
                        </li>
                        <li class="nav-item">
                            <a href="halaman_transaksi_kary.php">
                                <i class="fas fa-layer-group"></i>
                                <p>Transaksi</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="halaman_laporan_kary.php">
                                <i class="fas fa-th-list"></i>
                                <p>Laporan</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End Sidebar -->

        <div class="main-panel">
            <div class="content">
                <div class="panel-header bg-danger-gradient">
                    <div class="page-inner py-5">
                        <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                            <div>
                                <h2 class="text-white pb-2 fw-bold">Transaksi</h2>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="page-inner mt--5">

                    <div class="row row-card-no-pd">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-head-row card-tools-still-right">
                                        <h4 class="card-title">Data Transaksi</h4>
                                    </div>
                                    <a href="#tambah_"
                                        style="float: right; margin-right: 20px; color: white; border-radius: 30px; "
                                        class="btn btn-danger" data-toggle="modal">Tambah transaksi</a>
                                    <p class="card-category">
                                        Menampilkan data transaksi: <b><?= $transaksi; ?></b></p>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table id="add-row" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                    <th>NO</th>
                                                    <th>No nota</th>
                                                    <th>Pelanggan</th>
                                                    <th>Jenis</th>
                                                    <th>Total bayar</th>
                                                    <th>Tanggal</th>
                                                    <th>Action</th>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    include_once('php/koneksi.php');
                                                    $no = 1;
                                                    $sql = "SELECT * FROM tb_transaksi";

                                                    //use for MySQLi-OOP
                                                    $query = $db->query($sql);
                                                    while ($data = $query->fetch_assoc()) {
                                                        echo
                                                        "<tr>
			<td>" . $no++ . "</td>
			<td>" . $data['no_nota'] . "</td>
			<td>" . $data['nama_pelanggan'] . "</td>
			<td>" . $data['jenis'] . "</td>
			<td>" . $data['total_bayar'] . "</td>
			<td>" . $data['tanggal'] . "</td>
			<td>
				<a href='#edit_" . $data['no_nota'] . "' class='btn btn-info btn-sm' data-toggle='modal'><span class='fa fa-edit'></span> </a>
			</td>
		</tr>";

                                                        include('1_edit_delete_modal_transaksi_kary.php');
                                                    }


                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <!-- MODAL TAMBAHHH!! -->

            <div class="modal fade" id="tambah_" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title" id="exampleModalLabel"><b>Tambah data transaksi</b></h3>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">x</button>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid">
                                <form method="POST" action="php/tambah_transaksi_kary.php"
                                    enctype="multipart/form-data">
                                    <input type="hidden" class="form-control" name="no_nota">
                                    <div class="row form-group">
                                        <div class="col-sm-2 mt-2">
                                            <label class="control-label modal-label">Nama</label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="nama_pelanggan"
                                                placeholder="Masukkan nama">
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col-sm-2 mt-2">
                                            <label class="control-label modal-label">Jenis</label>
                                        </div>
                                        <div class="col-sm-10">
                                            <select name="jenis" id="" class="form-control">

                                                <?php
                                                $sql = "SELECT * FROM tb_biaya WHERE kendaraan='mobil'";
                                                $sql2 = "SELECT * FROM tb_biaya WHERE kendaraan='motor'";

                                                //use for MySQLi-OOP
                                                $query = $db->query($sql);
                                                $query2 = $db->query($sql2);
                                                $row = $query->fetch_assoc();
                                                $row2 = $query2->fetch_assoc();
                                                ?>
                                                <option value="" hidden>Jenis kendaraan</option>
                                                <option value="<?= $row['kendaraan'] ?>"><?= $row['kendaraan'] ?>
                                                </option>
                                                <option value="<?= $row2['kendaraan'] ?>"><?= $row2['kendaraan'] ?>
                                                </option>

                                            </select>
                                        </div>
                                    </div>



                                    <div class="row form-group">
                                        <div class="col-sm-2 mt-2">
                                            <label class="control-label modal-label">Total bayar</label>
                                        </div>
                                        <div class="col-sm-10">
                                            <select name="total_bayar" id="" class="form-control">
                                                <?php
                                                $sql = "SELECT * FROM tb_biaya WHERE kendaraan='mobil'";
                                                $sql2 = "SELECT * FROM tb_biaya WHERE kendaraan='motor'";

                                                //use for MySQLi-OOP
                                                $query = $db->query($sql);
                                                $query2 = $db->query($sql2);
                                                $row = $query->fetch_assoc();
                                                $row2 = $query2->fetch_assoc();
                                                ?>
                                                <option value="" hidden>Biaya</option>
                                                <option value="<?= $row['bayar'] ?>"><?= $row['bayar'] ?>
                                                </option>
                                                <option value="<?= $row2['bayar'] ?>"><?= $row2['bayar'] ?>
                                                </option>

                                            </select>
                                        </div>
                                    </div>

                                    <div class="row form-group">

                                        <div class="col-sm-10">
                                            <input type="date" class="form-control" name="tanggal"
                                                placeholder="Masukkan total bayar" hidden
                                                value=" <?= date("Y-m-d"); ?> ">
                                        </div>
                                    </div>

                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal"><span
                                    class="glyphicon glyphicon-remove"></span> Cancel</button>
                            <button type="submit" class="btn btn-danger"><span class="glyphicon glyphicon-check"></span>
                                Tambah
                                </form>
                        </div>
                    </div>
                </div>
            </div>



        </div>

        <!-- End Custom template -->
    </div>
    <!--   Core JS Files   -->
    <script src="assets/js/core/jquery.3.2.1.min.js"></script>
    <script src="assets/js/core/popper.min.js"></script>
    <script src="assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery UI -->
    <script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    <script src="assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


    <!-- Chart JS -->
    <script src="assets/js/plugin/chart.js/chart.min.js"></script>

    <!-- jQuery Sparkline -->
    <script src="assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

    <!-- Chart Circle -->
    <script src="assets/js/plugin/chart-circle/circles.min.js"></script>

    <!-- Datatables -->
    <script src="assets/js/plugin/datatables/datatables.min.js"></script>

    <!-- Bootstrap Notify -->
    <script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    <!-- jQuery Vector Maps -->
    <script src="assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
    <script src="assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

    <!-- Sweet Alert -->
    <script src="assets/js/plugin/sweetalert/sweetalert.min.js"></script>

    <!-- Atlantis JS -->
    <script src="assets/js/atlantis.min.js"></script>

    <!-- Atlantis DEMO methods, don't include it in your project! -->
    <script>
    $('#add-row').DataTable({
        "pageLength": 5,
    });
    </script>
</body>

</html>