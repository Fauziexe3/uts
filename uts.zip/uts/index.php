<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8">
    <title>DeskApp - Bootstrap Admin Dashboard HTML Template</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/login/vendors/images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/6.jpg">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Google Font -->

    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="assets/login/vendors/styles/core.css">
    <link rel="stylesheet" type="text/css" href="assets/login/vendors/styles/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="assets/login/vendors/styles/style.css">

    <!-- Global site tag (gtag.js) - Google Analytics -->

</head>

<body class="login-page">

    <div class="login-wrap d-flex align-items-center flex-wrap justify-content-center">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 col-lg-7">
                    <img src="assets/login/vendors/images/2.png" alt="">
                </div>
                <div class="col-md-6 col-lg-5">
                    <div class="login-box bg-white box-shadow border-radius-10">
                        <div class="login-title">
                            <h2 class="text-center text-danger">Login </h2>
                        </div>
                        <form action="php/login.php" method="post" enctype="multipart/form-data">
                            <div class="input-group custom">
                                <input type="text" class="form-control form-control-lg" placeholder="Username"
                                    name="username">
                                <div class="input-group-append custom">
                                    <span class="input-group-text"><i class="icon-copy dw dw-user1"></i></span>
                                </div>
                            </div>
                            <div class="input-group custom">
                                <input type="password" class="form-control form-control-lg" placeholder="**********"
                                    name="password">
                                <div class="input-group-append custom">
                                    <span class="input-group-text"><i class="dw dw-padlock1"></i></span>
                                </div>
                            </div>
                            <div class="row pb-2">
                                <div class="col-6">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="customCheck1">
                                        <label class="custom-control-label" for="customCheck1">Remember</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="forgot-password"><a href="forgot-password.html">Forgot Password</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group mb-0">
                                        <!--
											use code for form submit
											<input class="btn btn-primary btn-lg btn-block" type="submit" value="Sign In">
										-->
                                        <input class="btn btn-info btn-lg btn-block" type="submit" value="Sign In">
                                    </div>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="text-center text-danger">Register </h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="php/register.php" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <input type="text" class="form-control" id="recipient-name" placeholder="Masukkan username"
                                name="username">
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="recipient-name" placeholder="Masukkan nama anda"
                                name="nama">
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" id="recipient-name"
                                placeholder="Masukkan password" name="password">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                            <button type="submit" class="btn btn-danger">Daftar!</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- js -->
    <script src="assets/login/vendors/scripts/core.js"></script>
    <script src="assets/login/vendors/scripts/script.min.js"></script>
    <script src="assets/login/vendors/scripts/process.js"></script>
    <script src="assets/login/vendors/scripts/layout-settings.js"></script>
</body>

</html>