<?php
include 'koneksi.php';
$no_nota = $_GET['no_nota'];
mysqli_query($db, "DELETE FROM tb_transaksi WHERE no_nota='$no_nota'");


header("location: ../halaman_transaksi_kary.php");