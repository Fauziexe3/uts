<?php
include 'koneksi.php';
$id = $_GET['id'];
mysqli_query($db, "DELETE FROM user WHERE id='$id'");


header("location: ../halaman_data_user.php");