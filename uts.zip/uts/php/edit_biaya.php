<?php

include 'koneksi.php';
$id = $_POST['id'];
$kendaraan = $_POST['kendaraan'];
$bayar = $_POST['bayar'];


mysqli_query($db, "UPDATE tb_biaya SET id='$id', kendaraan='$kendaraan', bayar='$bayar' WHERE id='$id'");
header("location:../halaman_data_biaya.php");