<?php

include 'koneksi.php';
$no_nota = $_POST['no_nota'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$jenis = $_POST['jenis'];
$total_bayar = $_POST['total_bayar'];
$tanggal = $_POST['tanggal'];


mysqli_query($db, "UPDATE tb_transaksi SET no_nota='$no_nota', nama_pelanggan='$nama_pelanggan', jenis='$jenis', total_bayar='$total_bayar', tanggal='$tanggal' WHERE no_nota='$no_nota'");
header("location:../halaman_transaksi.php");