<?php

include 'koneksi.php';
$id = $_POST['id'];
$username = $_POST['username'];
$nama = $_POST['nama'];
$role_id = $_POST['role_id'];


mysqli_query($db, "UPDATE user SET id='$id', username='$username', nama='$nama', role_id='$role_id' WHERE id='$id'");
header("location:../halaman_data_user.php");