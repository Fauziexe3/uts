<?php
$db = mysqli_connect('localhost', 'root', '', '1_achmadfauzi_xiirpl');