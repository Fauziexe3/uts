<?php
include '../php/koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];


// if ($username == 'admin@gmail.com' && $pasword == 'admin123') {
//     session_start();
//     $_SESSION ['user'] = $username;
//     $_SESSION ['status'] = 'login';

//     header('location:coba.php');
// }else{
//     echo "pasword salah";
// }
$login = mysqli_query($db, "select * from user where username='$username' and password='$password'");
$cek = mysqli_num_rows($login);
// var_dump($cek);
// die;
// $isi = mysqli_fetch_array($login);


// if ($isi['username'] = $username  and $password = $isi['password']) {
//    session_start();
//    $_SESSION['user'] = "$username";
//    $_SESSION['status'] = "login";
//    header('location: coba.php');
// } else{
//     echo "salah.....!!!!";
// }


if ($cek > 0) {
    while ($i = mysqli_fetch_array($login)) {
        session_start();
        $_SESSION['user'] = $i['role_id'];
        $_SESSION['id'] = $i['id'];

        if ($i['role_id'] == "admin") {
            header("location: ../dashboard.php");
        }
        if ($i['role_id'] == "karyawan") {
            header("location: ../dashboard_kary.php");
        }
    }
} else {
    header("location: ../index.php");
}