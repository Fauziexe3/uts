<?php
include "../php/koneksi.php";
$username = $_POST['username'];
$nama = $_POST['nama'];
$password = $_POST['password'];
$role_id = "karyawan";

mysqli_query($db, "insert into user value('$id','$username', '$nama' ,'$password','$role_id')");
header('location: ../index.php');