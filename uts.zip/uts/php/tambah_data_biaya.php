<?php
session_start();

include "koneksi.php";
$kendaraan = $_POST['kendaraan'];
$bayar = $_POST['bayar'];


mysqli_query($db, "insert into tb_biaya value('$id','$kendaraan','$bayar')");

header('location: ../halaman_data_biaya.php');