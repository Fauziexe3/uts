<?php
session_start();

include "koneksi.php";
$nama_pelanggan = $_POST['nama_pelanggan'];
$jenis = $_POST['jenis'];
$total_bayar = $_POST['total_bayar'];
$tanggal = date("Y-m-d H:i:s");


mysqli_query($db, "insert into tb_transaksi value('$no_nota','$nama_pelanggan','$jenis' ,'$total_bayar', '$tanggal')");

header('location: ../halaman_transaksi_kary.php');